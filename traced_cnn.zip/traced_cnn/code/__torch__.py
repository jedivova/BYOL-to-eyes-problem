class sCNN(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  conv1 : __torch__.torch.nn.modules.conv.Conv2d
  pool1 : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv2d
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_1.Conv2d
  pool2 : __torch__.torch.nn.modules.conv.___torch_mangle_2.Conv2d
  conv3 : __torch__.torch.nn.modules.conv.___torch_mangle_3.Conv2d
  pool3 : __torch__.torch.nn.modules.conv.___torch_mangle_4.Conv2d
  avgpool : __torch__.torch.nn.modules.pooling.AdaptiveAvgPool2d
  relu : __torch__.torch.nn.modules.activation.ReLU
  fc : __torch__.torch.nn.modules.linear.Linear
  def forward(self: __torch__.sCNN,
    input: Tensor) -> Tensor:
    _0 = self.avgpool
    _1 = self.pool3
    _2 = self.conv3
    _3 = self.pool2
    _4 = self.conv2
    _5 = self.pool1
    _6 = self.relu
    _7 = (_6).forward((self.conv1).forward(input, ), )
    _8 = (_6).forward1((_4).forward((_5).forward(_7, ), ), )
    _9 = (_6).forward2((_2).forward((_3).forward(_8, ), ), )
    _10 = torch.flatten((_0).forward((_1).forward(_9, ), ), 1, -1)
    return _10
